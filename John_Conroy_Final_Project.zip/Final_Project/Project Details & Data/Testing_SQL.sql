SELECT *
FROM Hotel h;

SELECT *
FROM Room r;

SELECT *
FROM RoomAmenities ra;

SELECT *
FROM Images i;

SELECT *
FROM Reservation r;